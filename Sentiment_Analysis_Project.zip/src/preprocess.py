import pandas as pd
import re
import string

def clean_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = text.strip()
    return text

def load_and_preprocess(path):
    df = pd.read_csv(path)
    df['review'] = df['review'].apply(clean_text)
    return df
