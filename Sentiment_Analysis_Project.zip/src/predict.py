import pickle
import re
import string

def clean_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = text.strip()
    return text

with open("../models/sentiment_model.pkl", "rb") as f:
    model, vectorizer = pickle.load(f)

def predict_sentiment(text):
    text = clean_text(text)
    vectorized_text = vectorizer.transform([text])
    prediction = model.predict(vectorized_text)
    return prediction[0]

if __name__ == "__main__":
    user_input = input("Enter review: ")
    result = predict_sentiment(user_input)
    print("Sentiment:", result)
