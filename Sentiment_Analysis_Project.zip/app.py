from src.predict import predict_sentiment

print("===== Sentiment Analysis App =====")

while True:
    text = input("\nEnter a review (or type 'exit'): ")
    if text.lower() == 'exit':
        break

    result = predict_sentiment(text)
    print("Predicted Sentiment:", result)
