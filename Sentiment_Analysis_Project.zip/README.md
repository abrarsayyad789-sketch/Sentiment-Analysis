# Sentiment Analysis Project

## Description
This project performs sentiment analysis on text reviews using:
- TF-IDF Vectorization
- Logistic Regression
- Text Preprocessing

## Steps to Run

1. Install dependencies:
   pip install -r requirements.txt

2. Train the model:
   cd src
   python train_model.py

3. Run the application:
   python app.py

## Output
The model predicts whether a review is Positive or Negative.
